# Changelog

## v1.0
- Full-stack restaurant ordering app on GCP App Engine
- Auth (register/login/logout), cart, checkout, orders, rewards points
- SQLAlchemy (SQL) + Firestore (NoSQL)
- REST endpoints and pytest suite with evidence outputs
